<?php include('connect.php'); ?>
<?php 
	
    if(isset($_GET['direction']))
    {
        $direction = $_GET['direction'];

        if($direction != "delete")
        {
            $udregistrationsql = "INSERT INTO `direction` (`id`, `dirname`) VALUES (NULL, '$direction');";
            $resReg = mysqli_query($conn,$udregistrationsql);
            $count = mysqli_affected_rows($conn);
        }
    }
?>
<!DOCTYPE html>
<html>
    <head> 
        <link rel="stylesheet" href="style.css" />
    </head>

<body contenteditable="false">

 

<h1>L</h1>

<br>
<br>
<br>
    
    <br>
<br>
    <br>

<br>
<br>
<a href="up.php?direction=U" class="button" style="width:10%;">Up</a> 
<br>
<br>
<a href="left.php?direction=L" class="button1" style="width:10%;">Left</a> 
<a href="stop.php?direction=Delete" class="button4" style="width:10%;">Stop</a> 
<a href="right.php?direction=R" class="button2" style="width:10%;">Right</a>
<br>
<br>
<a href="down.php?direction=D" class="button3" style="width:10%;">Down</a> 

</body> </html>